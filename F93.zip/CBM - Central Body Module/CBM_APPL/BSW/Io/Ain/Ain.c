/* START OF FILE */
/* INCLUDE START */
#include "Ain.h"
#include "InputCtrl.h"
#include "adc.h"
#include "main.h"
#include <math.h>
#include <stdlib.h>
/* INCLUDE END */
/* DEFINE START */
/* DEFINE STOP */
/* VARIABLES START */
static uint8 Ain_ConversionComplete = 0;
uint16 Ain_Mux[4] = {0};
uint32 Adc_Error[3];
/* VARIABLES END */
/* FUNCTIONS START */
extern void Dem_SaveDtc(uint8 index, uint8 status);
void Ain_MainFunction(void);
void HAL_ADC_ErrorCallback(ADC_HandleTypeDef *hadc);
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc);
/* FUNCTIONS END */
/* FUNCTIONS START */
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
	Ain_ConversionComplete = 1;
}
void HAL_ADC_ErrorCallback(ADC_HandleTypeDef *hadc)
{
	static uint32 status = 0;
	status = HAL_ADC_GetError(&hadc1);
	switch(status)
	{
	case HAL_ADC_ERROR_INTERNAL:
		Adc_Error[0]++;
		break;
	case HAL_ADC_ERROR_OVR:
		Adc_Error[1]++;
		break;
	case HAL_ADC_ERROR_DMA:
		Adc_Error[2]++;
		break;
	}
}
void Ain_MainFunction(void)
{
	/* Status variable. */
	static uint32 status = 0;
	static uint32 counter = 0;
	static uint32 localCnt = 0;
	static uint32 localAvg[4] = {0, 0, 0, 0};
	/* Main counter. */
	static uint32 Ain_MainCounter = 0;
	/* Muxer pin iterator. */
	static uint8 Ain_CounterMux = 0;
	/* Check for error. */
	status = HAL_ADC_GetError(&hadc1);
	/* Call the error callback in case of error. */
	if(status) HAL_ADC_ErrorCallback(&hadc1);
	else for(uint8 i = 0; i < 3; i++) Adc_Error[i] = 0;
	/* Process the analog inputs coming from the muxer. */
	while(Ain_CounterMux < 4)
	{
		switch(Ain_CounterMux)
		{
		case 0: // 1 IGN
			HAL_GPIO_WritePin(SIG0_ADCMUX_GPIO_Port, SIG0_ADCMUX_Pin, 1);
			HAL_GPIO_WritePin(SIG1_ADCMUX_GPIO_Port, SIG1_ADCMUX_Pin, 0);
			HAL_GPIO_WritePin(SIG2_ADCMUX_GPIO_Port, SIG2_ADCMUX_Pin, 0);
			HAL_GPIO_WritePin(SIG3_ADCMUX_GPIO_Port, SIG3_ADCMUX_Pin, 0);
			break;
		case 1: // 2 LS
			HAL_GPIO_WritePin(SIG0_ADCMUX_GPIO_Port, SIG0_ADCMUX_Pin, 0);
			HAL_GPIO_WritePin(SIG1_ADCMUX_GPIO_Port, SIG1_ADCMUX_Pin, 1);
			HAL_GPIO_WritePin(SIG2_ADCMUX_GPIO_Port, SIG2_ADCMUX_Pin, 0);
			HAL_GPIO_WritePin(SIG3_ADCMUX_GPIO_Port, SIG3_ADCMUX_Pin, 0);
			break;
		case 2: // 8 GB
			HAL_GPIO_WritePin(SIG0_ADCMUX_GPIO_Port, SIG0_ADCMUX_Pin, 0);
			HAL_GPIO_WritePin(SIG1_ADCMUX_GPIO_Port, SIG1_ADCMUX_Pin, 0);
			HAL_GPIO_WritePin(SIG2_ADCMUX_GPIO_Port, SIG2_ADCMUX_Pin, 0);
			HAL_GPIO_WritePin(SIG3_ADCMUX_GPIO_Port, SIG3_ADCMUX_Pin, 1);
			break;
		case 3: // 5 RS
			HAL_GPIO_WritePin(SIG0_ADCMUX_GPIO_Port, SIG0_ADCMUX_Pin, 1);
			HAL_GPIO_WritePin(SIG1_ADCMUX_GPIO_Port, SIG1_ADCMUX_Pin, 0);
			HAL_GPIO_WritePin(SIG2_ADCMUX_GPIO_Port, SIG2_ADCMUX_Pin, 1);
			HAL_GPIO_WritePin(SIG3_ADCMUX_GPIO_Port, SIG3_ADCMUX_Pin, 0);
			break;
		default:
			break;
		}
		/* Start the measurement. */
		HAL_ADC_Start_IT(&hadc1);
		/* Refresh the end-of-conversion variable. */
		Ain_ConversionComplete = 0;
		/* Wait for conversion. */
		while(Ain_ConversionComplete == 0 && counter < 20000) counter++;
		if(20000 == counter) Dem_SaveDtc(0xA, 1);
		else
		{
			/* Do nothing. */
		}
		counter = 0;
		/* Get the measured value. */
		Ain_Mux[Ain_CounterMux] = HAL_ADC_GetValue(&hadc1);
		/* Stop the measurement. */
		HAL_ADC_Stop_IT(&hadc1);
		/* Get the next value in the muxer. */
		Ain_CounterMux++;
	}
	/* Reset the muxer counter.  */
	Ain_CounterMux = 0;
	/* Store the measured values. */
	if(localCnt % 20 == 0 && localCnt != 0)
	{
		for(uint8 i = 0; i < 4; i++)
		{
			StatusList_InputValue[i] = localAvg[i] / 20;
			localAvg[i] = 0;
		}
		localCnt = 0;
	}
	else
	{
		for(uint8 i = 0; i < 4; i++) localAvg[i] += Ain_Mux[i];
		localCnt++;
	}
	/* Increment the counter. */
	Ain_MainCounter++;
}
/* FUNCTIONS END */
/* STOP OF FILE */

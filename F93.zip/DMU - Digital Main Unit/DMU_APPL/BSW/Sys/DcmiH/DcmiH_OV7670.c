#include "DcmiH_OV7670.h"
#include "dcmi.h"
#include "dma.h"
#include "i2c.h"

const uint8 OV7670_reg[][2] =
{
		{0x12, 0x14},
		{0x8C, 0x00},
		{0x40, 0x10 + 0xc0},
		{0x3A, 0x04 + 8},
		{0x3D, 0x80 + 0x00},
		{0xB0, 0x84},
		{0x0C, 0x04},
		{0x3E, 0x19},
		{0x70, 0x3A},
		{0x71, 0x35},
		{0x72, 0x11},
		{0x73, 0xf1},
		{0x17, 0x16},
		{0x18, 0x04},
		{0x32, 0x80},
		{0x19, 0x03},
		{0x1a, 0x7b},
		{0x03, 0x0a},
		{0x4f, 0x80},
		{0x50, 0x80},
		{0x51, 0x00},
		{0x52, 0x22},
		{0x53, 0x5e},
		{0x54, 0x80},
		{0x58, 0x9e},
		{0x41, 0x38},
		{0x7b, 16},
		{0x7c, 30},
		{0x7d, 53},
		{0x7e, 90},
		{0x7f, 105},
		{0x80, 118},
		{0x81, 130},
		{0x82, 140},
		{0x83, 150},
		{0x84, 160},
		{0x85, 180},
		{0x86, 195},
		{0x87, 215},
		{0x88, 230},
		{0x89, 244},
		{0x7a, 16},
		{0x11, 0x00},
		{0x1E, 0x31},
		{REG_BATT, REG_BATT},
};
DCMI_HandleTypeDef *sp_hdcmi;
DMA_HandleTypeDef  *sp_hdma_dcmi;
uint32  s_destAddressForContiuousMode;
uint32 s_currentH;
uint32 s_currentV;
__attribute__((section(".ccmram"))) I2C_HandleTypeDef  *sp_hi2c;
__attribute__((section(".ccmram"))) uint32 DcmiH_MainCounter = 0;
__attribute__((section(".ccmram"))) uint32 DcmiH_Status = 0;
__attribute__((section(".ccmram"))) uint32 DcmiH_ErrArr[4] = {0};
__attribute__((section(".ccmram"))) uint32 DcmiH_DmaStatus = 0;
__attribute__((section(".ccmram"))) uint32 DcmiH_DmaErrArr[7] = {0};
extern DCMI_HandleTypeDef hdcmi;
extern I2C_HandleTypeDef hi2c1;
extern DMA_HandleTypeDef hdma_dcmi;
extern __attribute__((section(".ccmram"))) uint32 RevCam_DcmiStatus;
extern __attribute__((section(".ccmram"))) uint32 RevCam_DcmiInitRetry;
extern __attribute__((section(".ccmram"))) uint32 RevCam_OV7670InitRetry;

void (*s_cbHsync)(uint32 h);
void (*s_cbVsync)(uint32 v);
uint8 DcmiH_OV7670_Write(uint8 regAddr, uint8 data);
uint8 DcmiH_OV7670_Init(DCMI_HandleTypeDef *p_hdcmi, DMA_HandleTypeDef *p_hdma_dcmi, I2C_HandleTypeDef *p_hi2c);
uint8 DcmiH_OV7670_Config(uint32 mode);
uint8 DcmiH_OV7670_Start(uint32 capMode, uint32 destAddress);
uint8 DcmiH_OV7670_Stop();
void DcmiH_OV7670_RegisterCallback(void (*cbHsync)(uint32 h), void (*cbVsync)(uint32 v));
void HAL_DCMI_FrameEventCallback(DCMI_HandleTypeDef *hdcmi);
uint8 DcmiH_OV7670_InitHandler();
void DcmiH_MainFunction(void);

void DcmiH_MainFunction(void)
{
	DcmiH_Status = HAL_DCMI_GetState(&hdcmi);
	DcmiH_DmaStatus = HAL_DMA_GetState(&hdma_dcmi);
	/* Error reseting. */
	if(4 != DcmiH_Status || 4 != DcmiH_DmaStatus)
	{
		RevCam_DcmiStatus = 0;
		for(uint8 i = 0; i < 4; i++) DcmiH_ErrArr[i] = 0;
	}
	else
	{
		/* Retry initialization. */
		MX_DCMI_Init();
		RevCam_DcmiInitRetry++;
		RevCam_DcmiStatus = 0;
	}
	/* Error detection. */
	switch(hdma_dcmi.ErrorCode)
	{
	case HAL_DMA_ERROR_TE:
		DcmiH_DmaErrArr[0]++;
		RevCam_DcmiStatus = HAL_DMA_ERROR_TE;
		break;
	case HAL_DMA_ERROR_FE:
		DcmiH_DmaErrArr[1]++;
		RevCam_DcmiStatus = HAL_DMA_ERROR_FE;
		break;
	case HAL_DMA_ERROR_DME:
		DcmiH_DmaErrArr[2]++;
		RevCam_DcmiStatus = HAL_DMA_ERROR_DME;
		break;
	case HAL_DMA_ERROR_TIMEOUT:
		DcmiH_DmaErrArr[3]++;
		RevCam_DcmiStatus = HAL_DMA_ERROR_TIMEOUT;
		break;
	case HAL_DMA_ERROR_PARAM:
		DcmiH_DmaErrArr[4]++;
		RevCam_DcmiStatus = HAL_DMA_ERROR_PARAM;
		break;
	case HAL_DMA_ERROR_NOT_SUPPORTED:
		DcmiH_DmaErrArr[6]++;
		RevCam_DcmiStatus = HAL_DMA_ERROR_NOT_SUPPORTED;
		break;
	default:
		RevCam_DcmiStatus = 0;
		for(uint8 i = 0; i < 6; i++) DcmiH_DmaErrArr[i] = 0;
		break;
	}
	DcmiH_MainCounter++;
}
void HAL_DCMI_ErrorCallback(DCMI_HandleTypeDef *hdcmi)
{
	/* Error detection. */
	switch(hdcmi->ErrorCode)
	{
	case HAL_DCMI_ERROR_OVR:
		DcmiH_ErrArr[0]++;
		RevCam_DcmiStatus = HAL_DCMI_ERROR_OVR;
		break;
	case HAL_DCMI_ERROR_SYNC:
		DcmiH_ErrArr[1]++;
		RevCam_DcmiStatus = HAL_DCMI_ERROR_SYNC;
		break;
	case HAL_DCMI_ERROR_TIMEOUT:
		DcmiH_ErrArr[2]++;
		RevCam_DcmiStatus = HAL_DCMI_ERROR_TIMEOUT;
		break;
	case HAL_DCMI_ERROR_DMA:
		DcmiH_ErrArr[3]++;
		RevCam_DcmiStatus = HAL_DCMI_ERROR_DMA;
		break;
	default:
		RevCam_DcmiStatus = 0;
		break;
	}
}
uint8 DcmiH_OV7670_InitHandler()
{
	static uint8 retVal = 0;
	retVal = DcmiH_OV7670_Init(&hdcmi, &hdma_dcmi, &hi2c2);
	return retVal;
}
uint8 DcmiH_OV7670_Init(DCMI_HandleTypeDef *p_hdcmi, DMA_HandleTypeDef *p_hdma_dcmi, I2C_HandleTypeDef *p_hi2c)
{
	__enable_irq();
	static uint8 retVal = 0;
	sp_hdcmi     = p_hdcmi;
	sp_hdma_dcmi = p_hdma_dcmi;
	sp_hi2c      = p_hi2c;
	s_destAddressForContiuousMode = 0;
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, GPIO_PIN_SET);
	__enable_irq();
	HAL_Delay(1);
	__disable_irq();
	retVal = DcmiH_OV7670_Write(0x12, 0x80);
	do
	{
		/* Retry initialization. */
		__enable_irq();
		HAL_Delay(1);
		__disable_irq();
		retVal = DcmiH_OV7670_Write(0x12, 0x80);
		RevCam_OV7670InitRetry++;
	}while(retVal != 0 && RevCam_OV7670InitRetry < 10);
	__enable_irq();
	HAL_Delay(1);
	__disable_irq();
	__disable_irq();
	retVal = DcmiH_OV7670_Config(OV7670_MODE_QVGA_RGB565);
	return retVal;
}
uint8 DcmiH_OV7670_Config(uint32 mode)
{
	static uint8 retVal = 0;
	for(uint32 i = 0; OV7670_reg[i][0] != REG_BATT; i++)
	{
		retVal = DcmiH_OV7670_Write(OV7670_reg[i][0], OV7670_reg[i][1]);
		if(0 != retVal && RevCam_OV7670InitRetry < 10)
		{
			/* Retry initialization. */
			i = 0;
			RevCam_OV7670InitRetry++;
		}
		else
		{
			/* Do nothing. */
		}
	}
	return retVal;
}

uint8 DcmiH_OV7670_Start(uint32 capMode, uint32 destAddress)
{
	DcmiH_OV7670_Stop();
	if(capMode == OV7670_CAP_CONTINUOUS)
	{
		s_destAddressForContiuousMode = destAddress;
		HAL_DCMI_Start_DMA(sp_hdcmi, DCMI_MODE_CONTINUOUS, destAddress, OV7670_QVGA_WIDTH * OV7670_QVGA_HEIGHT / 2);
	}
	else if(capMode == OV7670_CAP_SINGLE_FRAME)
	{
		s_destAddressForContiuousMode = 0;
		HAL_DCMI_Start_DMA(sp_hdcmi, DCMI_MODE_SNAPSHOT, destAddress, OV7670_QVGA_WIDTH * OV7670_QVGA_HEIGHT / 2);
	}
	else
	{
		/* Do nothing. */
	}
	return 0;
}
uint8 DcmiH_OV7670_Stop()
{
	HAL_DCMI_Stop(sp_hdcmi);
	return 0;
}
void DcmiH_OV7670_RegisterCallback(void (*cbHsync)(uint32 h), void (*cbVsync)(uint32 v))
{
	s_cbHsync = cbHsync;
	s_cbVsync = cbVsync;
}
void HAL_DCMI_FrameEventCallback(DCMI_HandleTypeDef *hdcmi)
{
	if(s_cbVsync) s_cbVsync(s_currentV);
	else
	{
		/* Do nothing. */
	}
	if(s_destAddressForContiuousMode != 0) HAL_DMA_Start_IT(hdcmi->DMA_Handle, (uint32)&hdcmi->Instance->DR, s_destAddressForContiuousMode, OV7670_QVGA_WIDTH * OV7670_QVGA_HEIGHT / 2);
	else
	{
		/* Do nothing. */
	}
	s_currentV++;
	s_currentH = 0;
}
uint8 DcmiH_OV7670_Write(uint8 regAddr, uint8 data)
{
	HAL_StatusTypeDef ret = HAL_ERROR;
	do
	{
		ret = HAL_I2C_Mem_Write(sp_hi2c, SLAVE_ADDR, regAddr, I2C_MEMADD_SIZE_8BIT, &data, 1, 1);
	}while(ret != HAL_OK && 0);
	return ret;
}
